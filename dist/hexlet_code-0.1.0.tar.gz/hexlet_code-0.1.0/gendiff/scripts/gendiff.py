import argparse
from gendiff import generate_diff


def main():
    parser = argparse.ArgumentParser(description='Compares two configuration files and shows a difference.')
# ArgumentParser(prog='gendiff', usage=None, description='Compares two configuration files and shows a difference.', formatter_class=<class 'argparse.HelpFormatter'>, conflict_handler='error', add_help=True)

    parser.add_argument('first_file')
    parser.add_argument('second_file')
    parser.add_argument('-f', '--format', help="set format of output")
    
    args = parser.parse_args() 
# Namespace(first_file='file1.json', second_file='file2.json', format=None)

    file1 = args.first_file
    file2 = args.second_file
    print(generate_diff(file1, file2)) 
      

if __name__ == '__main__':
    main()


