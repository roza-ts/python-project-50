# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/roza-ts/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/roza-ts/python-project-50/actions)\n\n[![asciicast](https://asciinema.org/a/558234.svg)](https://asciinema.org/a/558234)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/c4c509708ac3d799361f/maintainability)](https://codeclimate.com/github/roza-ts/python-project-50/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/c4c509708ac3d799361f/test_coverage)](https://codeclimate.com/github/roza-ts/python-project-50/test_coverage)\n\n[![action](https://github.com/roza-ts/python-project-50/actions/workflows/action.yml/badge.svg)](https://github.com/roza-ts/python-project-50/actions/workflows/file.yml)\n\n',
    'author': 'roza-ts',
    'author_email': 'ayara2015@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
