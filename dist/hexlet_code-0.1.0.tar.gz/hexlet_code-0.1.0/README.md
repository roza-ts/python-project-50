### Hexlet tests and linter status:
[![Actions Status](https://github.com/roza-ts/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/roza-ts/python-project-50/actions)

[![asciicast](https://asciinema.org/a/558234.svg)](https://asciinema.org/a/558234)

[![Maintainability](https://api.codeclimate.com/v1/badges/c4c509708ac3d799361f/maintainability)](https://codeclimate.com/github/roza-ts/python-project-50/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/c4c509708ac3d799361f/test_coverage)](https://codeclimate.com/github/roza-ts/python-project-50/test_coverage)

[![action](https://github.com/roza-ts/python-project-50/actions/workflows/action.yml/badge.svg)](https://github.com/roza-ts/python-project-50/actions/workflows/file.yml)

